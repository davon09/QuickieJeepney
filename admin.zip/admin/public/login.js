// Add any client-side validation or handling here if necessary
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Send login credentials to the server via POST
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = '/admin'; // Redirect to the admin page
        } else {
            alert('Invalid login credentials');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
